#pragma once

enum BlockEntityType : int {
	BLOCKENTITY_NONE,
	Furnace,
	Chest,
	NetherReactor,
	Sign,
	MobSpawner,
	Skull,
	FlowerPot,
	BrewingStand,
	EnchantTable,
	DaylightDetector,
	NoteBlock,
	Comparator,
	Dispenser,
	Dropper,
	Hopper,
	Cauldron,
	ItemFrame
};
