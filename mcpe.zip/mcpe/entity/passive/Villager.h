#pragma once

#include "./../Mob.h"

class Villager : public Mob
{
public:
	Villager(BlockSource&);
	virtual ~Villager();
	virtual EntityType getEntityTypeId()const;
	virtual void readAdditionalSaveData(const CompoundTag*);
	virtual void addAdditionalSaveData(CompoundTag*);
	void normalTick();
};
