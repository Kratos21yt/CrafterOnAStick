#pragma once

class Entity;

class Sensing
{
public:
	bool canSee(Entity *);
};
