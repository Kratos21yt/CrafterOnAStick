#pragma once

enum class ItemRenderChunkType
{
	NORMAL,
	DISMISS,
	TEST
};
