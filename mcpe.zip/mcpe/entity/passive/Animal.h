#pragma once

#include "../AgableMob.h"

// Size : 3220
class Animal : public AgableMob
{
public:
	Animal(BlockSource &);
	virtual ~Animal(){}

};
