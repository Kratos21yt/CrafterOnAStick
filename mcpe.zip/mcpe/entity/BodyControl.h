#pragma once

// Size : 12
class BodyControl
{
public:
	BodyControl(Mob *);
	void clientTick();
};
