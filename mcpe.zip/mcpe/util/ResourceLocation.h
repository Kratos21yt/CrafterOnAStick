#pragma once

#include <string>

class ResourceLocation
{
public:
	std::string fullPath;
	std::string getFullPath()const;
};
