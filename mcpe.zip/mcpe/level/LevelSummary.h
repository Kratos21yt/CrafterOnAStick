#pragma once

// Size : 32
class LevelSummary
{
public:
	std::string name1;		// 0
	std::string levelName;	// 4
	int filler1;			// 8
	int gameMode;			// 12
	int filler2;			// 16
	int filler3;			// 20
	int filler4;			// 24
	int filler5;			// 24
};
