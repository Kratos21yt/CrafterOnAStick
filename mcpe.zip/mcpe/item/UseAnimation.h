#pragma once

enum class UseAnimation : unsigned char
{
	NOME,
	EAT,
	DRINK,
	BLOCK,
	BOW,
	CAMERA
};
