#pragma once
#include <string>
#include <memory>

class Common
{
public:
	static std::string getGameVersionStringNet(void);
	static std::string getGameVersionString(void); 
};
