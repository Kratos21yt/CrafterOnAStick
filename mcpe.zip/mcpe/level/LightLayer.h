#pragma once

class LightLayer
{
public:
	static const LightLayer BLOCK;
	static const LightLayer SKY;

public:
	char filler1[8];
};
