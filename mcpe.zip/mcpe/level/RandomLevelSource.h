#pragma once

class LevelChunk;

class RandomLevelSource
{
public:
	void prepareHeights(int, int, LevelChunk *);
};