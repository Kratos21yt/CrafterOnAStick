#pragma once

class Music;

class MusicManager
{
public:
	void stopPlaying(void);
	void startPlaying(Music&);
};
