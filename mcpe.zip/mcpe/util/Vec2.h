#pragma once

class Vec2
{
public:
	float x;	// 0
	float y;	// 4
};