#pragma once

enum class BlockSoundType : int
{
	SOUND_DEFAULT
};
