#pragma once

#include "Animal.h"

class Chicken : public Animal
{
public:
	
};
