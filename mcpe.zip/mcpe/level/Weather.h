#pragma once

class Weather
{
public:
	bool isRaining()const;
};
